﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.IO;

/**
 * Prosty program szyfrujący/deszyfrujący,
 * wykorzystujący w tym celu technikę szyfrowania AtBash
 * @ created by Mateusz Bierka
 ***/
 
namespace atBashEncoder
{
    class atBash
    {
        protected char[] alphabet = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
        protected int alphabetCount = 0;

        /**
         * 
         * Constructor
         * 
         ***/

        public atBash()
        {
            this.alphabetCount = this.alphabet.Length; // set alphabet length
        }

        /**
         * 
         * Funkcja szyfrująco-deszyfrująca
         * @ var (string) text
         * @ return (string)
         * 
         ***/

        public string enDeCode(string text)
        {
            string newText = "";
            int index = 0;

            for (int i = 0; i < text.Length; i++)
            {
                if ((index = Array.IndexOf(this.alphabet, text[i])) != -1)
                {
                    newText += this.alphabet[this.alphabetCount-(index+1)];
                }
                else
                {
                    newText += text[i];
                }
            }

            return newText;
        }
    }

    //===================================================//

    class aBProgram // atBash 
    {
        /**
         * 
         * Atrybuty
         * 
         ***/

        static byte modeInput = 0; // tryb wyboru źródła danych 
        static string[] modesInput =
        {
            "Z konsoli",
            "Z pliku"
        };

        static byte modeEnDeCode = 0; // tryb wyboru działania programu
        static string[] modesEnDeCode =
        {
            "Szyfrowanie",
            "Deszyfrowanie"
        };

        static string error = ""; // zmienna zawierająca treść błędu

        /**
         * 
         * Metoda wyświetlająca standardowe  
         * teksty znajdujące się na górze okna
         * @ return (void)
         * 
         ***/

        static void hello()
        {
            Console.WriteLine("Witaj w prostym programie szyfrującum w technice atBash\nTwórca: Mateusz Bierka");

            if (modeEnDeCode <= 0 || modeEnDeCode > modesEnDeCode.Length)
            {
                Console.WriteLine("\nWybierz tryb działania programu: ");
                for (int i = 0; i < modesEnDeCode.Length; i++)
                {
                    Console.WriteLine((i + 1) + ". " + modesEnDeCode[i]);
                }
            }
            else
            {
                Console.WriteLine("\nWybrany tryb działania programu: " + modesEnDeCode[modeEnDeCode - 1]);

                if (modeInput <= 0 || modeInput > modesInput.Length)
                {
                    Console.WriteLine("\nJak chcesz wprowadzić tekst do programu:");
                    for (int i = 0; i < modesInput.Length; i++)
                    {
                        Console.WriteLine((i + 1) + ". " + modesInput[i]);
                    }
                }
                else
                {
                    Console.WriteLine("\nWybrane źródło tekstu: " + modesInput[modeInput - 1]);
                }
            }

            Console.WriteLine("\n======================================================================\n");

            if (error != "") // pokaż ewentualne błędy
            {
                Console.WriteLine(error);
                error = ""; // wyczyść po pokazaniu
            }
        }

        /**
         * 
         * Metoda czyszcząca okno konsoli
         * Po wyczyszczeniu okna konsoli odświeża standardowe teksty
         * @ return (void)
         * 
         ***/

        static void clear()
        {
            Console.Clear();
            hello();
        }

        /**
         * 
         * Główna metoda programu 
         * @ return (void)
         * 
         ***/

        static void Main()
        {
            clear();

            //=========================================================// STEP 1

            while (modeEnDeCode <= 0 || modeEnDeCode > modesEnDeCode.Length)
            {
                try
                {
                    Console.Write("Wprowadź: ");
                    modeEnDeCode = byte.Parse(Console.ReadLine());
                }
                catch (Exception ex)
                {
                    error = "Błąd:\n" + ex.Message + "\n";
                }
                clear();
            }

            //=========================================================// STEP 2

            while (modeInput <= 0 || modeInput > modesInput.Length)
            {
                try
                {
                    Console.Write("Wprowadź: ");
                    modeInput = byte.Parse(Console.ReadLine());
                }
                catch (Exception ex)
                {
                    error = "Błąd:\n" + ex.Message + "\n";
                }
                clear();
            }

            //=========================================================// STEP 3

            string text = "";
            if (getTextFromSource(ref text)) // jeżeli prawda, nastąpił problem z plikiem, z powodu tego nastąpi powrót do wyboru w drugim kroku wraz z wyświetleniem tekstu błędu
            {
                modeInput = 0;
                Main();
            }
            else
            {
                atBash atBash = new atBash();

                Console.WriteLine("Wprowadzony tekst:\n\n" + text);
                Console.WriteLine("\n" + (modeEnDeCode == 1 ? "Zaszyfrowany" : "Odszyfrowany") + " tekst:\n\n" + atBash.enDeCode(text.ToLower()));
                    
                Console.WriteLine("\n======================================================================\n");

                //=========================================================// STEP 4

                string decision = "";
                while (decision.ToLower() != "n" && decision.ToLower() != "y")
                {
                    Console.Write("Czy chcesz dalej korzystać z programu ?\n\nWpisz N aby zakończyć działanie programu\nWpisz Y aby dalej z niego korzystać\n\nTwoja decyzja: ");
                    decision = Console.ReadLine();
                    clear();
                }
                if (decision.ToLower() == "y")
                {
                    modeInput = 0;
                    modeEnDeCode = 0;
                    Main();
                }
            }
                             
        }       

        /**
         * 
         * Metoda pobierająca tekst
         * z wybranego źródła
         * @ var ref (string) text
         * @ return (bool) 
         * 
         ***/

        static bool getTextFromSource(ref string text)
        {
            string pattern = @"^[a-z\s\n\t\W]+$"; // reg exp określający wymagany ciąg znaków
            bool success = false; // określa czy pobranie danych się powiodło

            Regex r = new Regex(pattern, RegexOptions.IgnoreCase); 

            while (!success)
            {
                switch (modeInput)
                {
                    case 1: success = getTextFromConsole(ref text, ref r); break;
                    case 2: success = getTextFromFile(ref text, ref r); break;
                } 
                if (!success) text = ""; // jeżeli pobranie danych się nie udało, wyczyść zmienną text
                if (modeInput == 2 && !success) return true; // przerwanie, pobranie danych z pliku się nie udało
                clear();
            }  

            return false;
        }

        /**
         * 
         * Metoda pobierająca tekst z konsoli        
         * @ var ref (string) text, ref (Regex) r
         * @ return (bool) 
         * 
         ***/

        static bool getTextFromConsole(ref string text, ref Regex r)
        {
            bool isSuccess = false;

            Console.Write("Wprowadź tekst: ");
            text = Console.ReadLine();

            Match m = r.Match(text);            
            error = (isSuccess = (m.Success && text.Trim().Length != 0)) ? "" : "Błąd:\nTekst musi się składać z samych liter alfabetu łacinśkiego, ewentulanie być przedzielony znakami interpukcyjnymi bądż znakami białymi.\n";

            return isSuccess;
        }

        /**
         * 
         * Metoda pobierająca tekst z pliku
         * @ var ref (string) text, ref (Regex) r
         * @ return (bool) 
         * 
         ***/

        static bool getTextFromFile(ref string text, ref Regex r)
        {
            bool isSuccess = false;

            try
            {
                using (StreamReader file = new StreamReader("filetoendecode.txt", Encoding.UTF8))
                {                    
                    text = file.ReadToEnd();
                }                                                      
            }
            catch (Exception ex)
            {
                error = "Błąd:\n" + ex.Message + "\n";
            }

            if (error == "")
            {
                Match m = r.Match(text);
                error = (isSuccess = (m.Success && text.Trim().Length != 0)) ? "" : "Błąd:\nTekst w pliku musi się składać z samych liter alfabetu łacinśkiego, ewentulanie być przedzielony znakami interpukcyjnymi bądż znakami białymi.\nPopraw go po czym wybierz ponownie sposób wprowadzenia tekstu do programu.\n";

                return isSuccess;
            }
            else return false;           
        }

    }
}
